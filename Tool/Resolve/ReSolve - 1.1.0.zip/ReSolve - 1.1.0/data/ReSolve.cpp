#include <iostream>
#include <math.h>
#include <string.h>
#include <string>
#include <map>
#define PI 3.1415926535898
using namespace std;

//Thong tin tac gia chuong trinh
void Info(){
    system("cls");
    cout<<"\n                     CHUONG TRINH TINH TOAN  "<<endl;
    cout<<"\n           Tac gia    : Ha Nguyen Tien Dat - DatIT"<<endl;
    cout<<"\n           Dien Thoai : 0948147172"<<endl;
    cout<<"\n           Email      : tiendatha2006@gmail.com"<<endl;
    cout<<"\n           Website    : http://firehelper.cf/"<<endl;
	cout<<"\n           Version    : 1.1.0"<<endl;
    cout << endl << endl;
    system("pause");
    system("cls");
}

//TIM SO NGUYEN TO
void SoNguyen(){
	system("cls");
    long n;
        cout<<"\n       TIM SO NGUYEN, BOI VA UOC  "<<endl;
        cout << "-------------------------------------\n\n";
	    cout << "Nhap so nguyen n = ";
	    //Tim uoc
	    do{
	        cin >> n;
	        cout << "\n-------------------------------------\n";
	        if(n <= 0 || n > 1000000){
	            cout << "\nNhap lai so nguyen n = ";
	        }
	    }
		while(n <= 0 || n > 1000000);

	    cout << "\nUoc cua " << n << " la: ";

	    for(int i = 1; i <= n; i++){
	        if(n % i == 0){
				cout << i << " ";
	        }
	    }

	    cout << "\nBoi cua " << n << " la: 0 ";

	    //Tim boi
	    	for(int i = n; i >= n && i < n + 100; i++){
	    		if(i % n == 0){
	    			cout << i << " ";
				}
			}

	    //Tim so nguyen to
	    if(n < 2){
	        cout << n << " khong phai so nguyen to\n";
	    }
	    int count = 0;
	    for(int i = 2; i <= sqrt(n); i++){
	        if(n % i == 0){
	            count++;
	        }
	    }
	    if(count == 0){
	    	cout << endl;
	        cout << n << " la so nguyen to\n";
	    }
		else{
			cout << endl;
	        cout << n << " khong phai so nguyen to\n";
	    }
	    cout << "\n-------------------------------------\n";
	    system("pause");
	    system("cls");
	    system("ReSolve.exe");
}

//CAN BANG PTHH
void PTHH(){
	system("PTHH.exe");
}

//PHUONG TRINH BAC 2
void PTB2(){
	system("PTB2.exe");
}

//PHUONG TRINH BAC 3
void PTB3(float a, float b, float c, float d){
  float dt, k, x1, x2, x3, x;
  if(a == 0){
    cout << "Phuong trinh vo nghiem" << endl;
  }
  dt = pow(b, 2) - 3 * a * c; //delta=b*b-3*a*c
  k = (9 * a * b * c - 2 * pow(b, 3) - 27 * pow(a, 2) * d) / (2 * sqrt(pow(fabs(dt), 3)));
  if(dt > 0)
  {
    if(fabs(k) <= 1){
      x1=(2*sqrt(dt)*cos(acos(k)/3)-b)/(3*a);
      x2=(2*sqrt(dt)*cos(acos(k)/3-(2*PI/3))-b)/(3*a);
      x3=(2*sqrt(dt)*cos(acos(k)/3+(2*PI/3))-b)/(3*a);
      cout<<"phuong trinh co 3 nghiem phan biet: "<<endl;
      cout<<"x1="<<x1<<endl;
      cout<<"x2="<<x2<<endl;
      cout<<"x3="<<x3<<endl;
    }
    if(fabs(k) > 1){
      x=((sqrt(dt)*fabs(k))/(3*a*k))*(pow((fabs(k)+sqrt(pow(k,2)-1)),1.0/3)+pow((fabs(k)-sqrt(pow(k,2)-1)),1.0/3))-(b/(3*a));
      cout<<"Phuong trinh co 1 ngiem duy nhat la: "<<x<<endl;
    }
   }
  else if(dt==0)
  {
    x=(-b-pow(-(pow(b,3)-27*a*a*d),1.0/3))/(3*a);//do ham pow khong dung doi so am nen ta phai doi dau.Ct goc:x=(-b+pow(pow(b,3)-27*a*a*d),1.0/3))/(3*a)
    cout<<"Phuong trinh co nghiem boi: "<<x<<endl;
  }
  else
  {
    x=(sqrt(fabs(dt))/(3*a))*(pow((k+sqrt(k*k+1)),1.0/3)-pow(-(k-sqrt(k*k+1)),1.0/3))-(b/(3*a));
    cout<<"phuong trinh co 1 nghiem duy nhat: "<<x<<endl;
  }
}

int main(){
	system("mode con cols=74 lines=15");
	cout <<"\n                 CHUONG TRINH TINH TOAN  -- DATIT -- v1.1.0       ";
        cout<<"\n     =================================================================";
        cout<<"\n     |(1) Tinh so nguyen va tim uoc, boi                             |";
        cout<<"\n     |(2) Giai PTB2 co dang ax^2 + bx + c = 0 (a<>0)                 |";
        cout<<"\n     |(3) Giai PTB3 co dang ax^3 + bx^2 + cx + d = 0 (a<>0)          |";
        cout<<"\n     |(4) Can bang PTHH (Su dung '=' thay vi '->')                   |";
        cout<<"\n     |(5) Truy tim nguyen to (Cancelled)                             |";
        cout<<"\n     =================================================================";
        cout<<"\n     |        Nhan Phim 0 De Xem Thong Tin Tac Gia Chuong Trinh      |";
        cout<<"\n     =================================================================";
        cout<<"\n                          Lua chon cua ban: ";

	float a, b, c, d;
	int chon;
    cin >> chon;

        if(chon == 0){
            Info();
            system("ReSolve.exe");
        }

        else if(chon == 1){
            SoNguyen();
        }
        else if(chon == 2){
            PTB2();
            system("ReSolve.exe");
        }

        else if(chon == 3){
        	system("cls");
        	cout << "Phan nay se hoan thien trong ban cap nhat sau" << endl;
        	cout << "-------------------------------------\n";
      		cout << "Nhap a: ";
      		cin >> a;
      		cout << "Nhap b: ";
			cin >> b;
			cout << "Nhap c: ";
			cin >> c;
			cout << "Nhap d: ";
			cin >> d;
      		PTB3(a, b, c, d);
      		cout << "\n-------------------------------------\n";
      		system("pause");
      		system("cls");
            system("ReSolve.exe");
        }

        else if(chon == 4){
            PTHH();
            system("ReSolve.exe");
        }
    return 0;
}


